﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conv
{
    public partial class Form1 : Form
    {
        string s1 = string.Empty;
        string s2 = string.Empty;

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            s1 = string.Empty;
            s2 = string.Empty;

            s1 = textBox1.Text;

            if (char.IsUpper(s1, 2))
            {
                //現在のカルチャを使用して、小文字に変換する
                s2 = s1.ToLower();
                //abcde
            }
            else
            {
                //現在のカルチャを使用して、大文字に変換する
                s2 = s1.ToUpper();
                //ABCDE
            }
            textBox2.Text = s2;
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
        }
    }
}
